package JDBC;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Miguel Lladó
 * @version NetBeans IDE 8.2
 */
public class Practica9 {
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entrada = new Scanner(System.in);
        boolean salir = false;
        try{
            System.out.print("---- GESTIÓN BASE DATOS -BEER- ----");
            while (!salir) {
                System.out.println("----------------------------");
                System.out.println("-- Menú de opciones -- ");
                System.out.println("----------------------------");
                System.out.println("1. Actualizar");
                System.out.println("2. Consultar");
                System.out.println("3. Insertar");
                System.out.println("4. Salir");

                System.out.println("Seleccione una de las opciones para ir al "
                        + "menú deseado");
                int opcion = entrada.nextInt();
                switch (opcion) {
                    case 1:
                        ActualizarBD();
                        break;
                    case 2:
                        ConsultarBD();
                        break;
                    case 3:
                        InsertarBD();
                        break;
                    case 4:
                        salir = true;
                        break;
                    default:
                        System.out.println("Por favor, seleccione una opción "
                                + "válida (de 1, a la 3)\n");
                }
            }
        } catch (SQLException error) {
            System.out.println(error.getSQLState() + error.getMessage());
        } catch (IOException error) {
            System.out.println("Error de entrada/salida" + error.getMessage());
        }catch (Exception error) {
            System.out.println("Error no controlado" + error.getMessage());
        } finally {
        }   
    }
    
    public static void ConsultarBD() throws Exception{

        Connection miConexion = DriverManager.getConnection("jdbc:mysql://"
                + "localhost:3306/beer", "root", "root");
        Statement miStatement = miConexion.createStatement();
        ResultSet miResultado = miStatement.executeQuery("SELECT * "
                + "FROM dinker");
        FileWriter fichero = new FileWriter("E:\\Ejercicio9\\consulta.txt");
        PrintWriter pw = new PrintWriter(fichero);
        pw.println("En la tabla SERVES tenemos estos datos");
        while (miResultado.next()) {
            String nombre = miResultado.getString("name");
            pw.println("Nombre del bar" + nombre);
            String direccion = miResultado.getString("address");
            pw.println("Dirección del bar" + direccion);
        }
        if( miResultado!=null)  miResultado.close();
        if( miStatement!=null)  miStatement.close();
        if( miConexion!=null)  miConexion.close();
    }
   
    public static  void ActualizarBD() throws Exception {	
        Connection miConexion = null;
        try {    
            miConexion = DriverManager.getConnection("jdbc:mysql://localhost"
                    + ":3306/pruebas", "root", "root");
            miConexion.setAutoCommit(false);
            Statement miStatement = miConexion.createStatement();
            System.out.print("¿Cuántas filas quieres actualizar?: ");
            Scanner entrada = new Scanner(System.in);
            int filas = entrada.nextInt();
            for (int i=0;i<filas;i++){
                List<String> datos = valores();
                String instruccionSql_1 = "UPDATE serves SET  price=? WHERE  "
                        + "bar=? & beer=?";
                PreparedStatement update = miConexion.prepareStatement
        (instruccionSql_1);
                update.setString(1, datos.get(0));
                update.setString(2, datos.get(1));
                miStatement.executeUpdate(instruccionSql_1);
            }
            miConexion.commit();
            System.out.println("Datos INSERTADOS correctamente");
            miConexion.setAutoCommit(true);
        } catch (Exception e) {
            System.out.println("ERROR EN LA ACTUALIZACIÓN DE DATOS!!");
            try {
                miConexion.rollback();
                } catch (SQLException ex) {
                }
        }finally {
            if( miConexion!=null)  miConexion.close();
        }
    }

    public static void InsertarBD() throws Exception {
        Connection miConexion = null;
        try {
            miConexion = DriverManager.getConnection("jdbc:mysql://"
                    + "localhost:3306/beer", "root", "admingenius09");
            miConexion.setAutoCommit(false);
            String insertar1 = "INSERT INTO bar (name, address) VALUES (?, ?)";
            String insertar2 = "INSERT INTO drinker (name, address) VALUES "
                    + "(?, ?)";
            PreparedStatement bar1 = miConexion.prepareStatement(insertar1);
            PreparedStatement bar2 = miConexion.prepareStatement(insertar2);
            bar1.setString(1, "Nombre1");
            bar1.setString(2, "Direccion1");
            bar2.setString(1, "Nombre2");
            bar2.setString(2, "Direccion2");
            int num1 = bar1.executeUpdate();
            int num2 = bar2.executeUpdate();
            miConexion.commit();
            System.out.println("ACTUALIZADA CON ÉXITO");
            miConexion.setAutoCommit(true);
        } catch (SQLException e) {
            System.out.println("ERROR EN LA ACTUALIZACIÓN DE DATOS!!");
            try {
                miConexion.rollback();
                } catch (SQLException ex) {
                }
        }finally {
            if( miConexion!=null)  miConexion.close();
        }
    }
    
    public static List valores() throws Exception {
        List<String> datos = new ArrayList();
        Scanner input = new Scanner(System.in);
        String nombeer;
        String nombar;
        boolean bar = false;
        boolean beer = false;
        while (!bar) {
            System.out.println("\nIntroduzca el nombre del bar :");
            nombar = input.nextLine();
            if (!nombar.isEmpty()) {
                datos.add(nombar);
                bar = true;
            } else {
                System.out.println("Escriba un nombre, por favor");
            }
        }
        while (!beer) {
            System.out.println("\nIntroduzca la dirección del bar :");
            nombeer = input.nextLine();
            if (!nombeer.isEmpty()) {
                datos.add(nombeer);
                beer = true;
            } else {
                System.out.println("Escriba un nombre, por favor");
            }
        }
        return datos;
    } 
}
